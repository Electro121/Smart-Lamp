
FREE APP

Created by WebIntoApp.com on Wednesday 16th of August 2023 08:23:50 PM.

Release APK & App Bundle (AAB) ready to be submitted to Google Play Store 
and to any other APK / AAB store over the internet.

-------------------------------------
App ID:			135241
App Key:		ztsvdaPBHshBYmtURolKMvXboMNSruqS
App Name:		Twinkle 2
App Version:	1.0
Package:		com.rs63roboticsgroup5.twinkle
Mode:			Free App
-------------------------------------

Your free app is ready, you can now publish it to the 
google play store and to any apk app store on the internet.

-------------------------------------
Please note, your app is under a FREE mode, you can always 
convert it to your own dedicated and branded mobile app for 
Android and iOS with all the premium features at:

https://www.webintoapp.com/author/apps/135241/edit?cmd=app-switcher

-------------------------------------
Here are some useful links:
-------------------------------------

You can edit your app at:
https://www.webintoapp.com/author/apps

Get installs statistics at:
https://www.webintoapp.com/author/stats?appid=135241

The Author Area:
https://www.webintoapp.com/author/dashboard

-------------------------------------
WebIntoApp.com Team.
https://www.webintoapp.com
-------------------------------------
